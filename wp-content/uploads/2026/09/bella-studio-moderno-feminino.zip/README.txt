BELLA STUDIO — TEMA WORDPRESS

Instalação:
1. No WordPress, vá em Aparência > Temas > Adicionar novo > Enviar tema.
2. Envie o arquivo ZIP.
3. Ative o tema.
4. Vá em Aparência > Personalizar.
5. Em "Bella Studio - Hero", configure:
   - WhatsApp (somente números), exemplo: 5511999999999
   - Imagem principal
   - Vídeo de fundo do ambiente.

Vídeo:
- Recomendado: MP4 H.264.
- Use vídeo curto, leve e sem áudio. O tema já usa autoplay + muted + loop + playsinline.
- Para melhor performance, comprima o vídeo antes de enviar.

Animações:
- Classes .reveal, .reveal-left e .reveal-right usam IntersectionObserver.
- Elementos entram quando aparecem no viewport.
- Ao voltar para cima, o efeito de entrada pode ser repetido.
- Respeita prefers-reduced-motion.
