document.addEventListener('DOMContentLoaded', () => {
  const header = document.querySelector('.site-header');
  const toggle = document.querySelector('.menu-toggle');
  const menu = document.querySelector('.menu');

  const onScroll = () => {
    if (header) header.classList.toggle('scrolled', window.scrollY > 30);
  };
  onScroll();
  window.addEventListener('scroll', onScroll, {passive:true});

  if (toggle && menu) {
    toggle.addEventListener('click', () => {
      const open = menu.classList.toggle('open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    menu.querySelectorAll('a').forEach(a => a.addEventListener('click', () => menu.classList.remove('open')));
  }

  const revealItems = document.querySelectorAll('.reveal, .reveal-left, .reveal-right');
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
        } else if (entry.boundingClientRect.top > 0) {
          // Mantém o efeito de entrada ao voltar para cima, sem ficar preso em estado invisível.
          entry.target.classList.remove('is-visible');
        }
      });
    }, {threshold: 0.14, rootMargin: '0px 0px -8% 0px'});
    revealItems.forEach(el => observer.observe(el));
  } else {
    revealItems.forEach(el => el.classList.add('is-visible'));
  }

  // Parallax sutil em elementos marcados.
  const parallax = document.querySelectorAll('[data-parallax]');
  if (parallax.length && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    window.addEventListener('scroll', () => {
      const y = window.scrollY;
      parallax.forEach(el => {
        const speed = parseFloat(el.dataset.parallax || '0.08');
        el.style.transform = `translateY(${y * speed * -1}px)`;
      });
    }, {passive:true});
  }
});