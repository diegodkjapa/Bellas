<footer class="site-footer">
  <div class="container">
    <div class="footer-grid">
      <div>
        <a class="logo" href="<?php echo esc_url(home_url('/')); ?>">Bella<span>Studio</span></a>
        <p>Beleza, cuidado e autoestima em cada detalhe.</p>
      </div>
      <div>
        <strong>Agende seu horário</strong>
        <p><a href="<?php echo esc_url(bella_studio_whatsapp_url()); ?>" target="_blank" rel="noopener">Falar pelo WhatsApp →</a></p>
      </div>
    </div>
    <div class="footer-bottom">© <?php echo date('Y'); ?> Bella Studio. Todos os direitos reservados.</div>
  </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
