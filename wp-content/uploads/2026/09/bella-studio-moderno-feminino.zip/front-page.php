<?php get_header(); ?>
<main>
<section class="hero">
  <div class="container hero-grid">
    <div class="hero-copy reveal-left">
      <div class="eyebrow">Seu momento de beleza</div>
      <h1>Realce sua beleza. Sinta-se ainda mais você.</h1>
      <p>Um espaço pensado para você desacelerar, se cuidar e sair daqui se sentindo incrível.</p>
      <div class="actions">
        <a class="btn btn-primary" href="<?php echo esc_url(bella_studio_whatsapp_url('Olá! Gostaria de agendar um horário.')); ?>" target="_blank" rel="noopener">Agendar meu horário</a>
        <a class="btn btn-light" href="#servicos">Conhecer serviços</a>
      </div>
    </div>
    <div class="hero-media reveal-right">
      <div class="hero-card">
        <?php $hero = get_theme_mod('bella_hero_image'); ?>
        <?php if ($hero): ?>
          <img src="<?php echo esc_url(wp_get_attachment_image_url($hero, 'large')); ?>" alt="Ambiente do salão">
        <?php else: ?>
          <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/placeholder.svg'); ?>" alt="Imagem principal do salão">
        <?php endif; ?>
      </div>
      <div class="badge">✦ Atendimento personalizado<br><strong>Feito para você</strong></div>
    </div>
  </div>
</section>

<section id="servicos" class="section">
  <div class="container">
    <div class="section-head reveal">
      <div class="kicker">Nossos serviços</div>
      <h2>Beleza com cuidado em cada detalhe.</h2>
      <p>Escolha seu momento e deixe o resto com a nossa equipe.</p>
    </div>
    <div class="services-grid">
      <article class="service-card reveal delay-1"><div class="service-icon">✦</div><h3>Cabelos</h3><p>Corte, escova, coloração, mechas e tratamentos para valorizar seu estilo.</p></article>
      <article class="service-card reveal delay-2"><div class="service-icon">♡</div><h3>Unhas</h3><p>Manicure e pedicure com acabamento impecável e aquele tempo para você.</p></article>
      <article class="service-card reveal delay-3"><div class="service-icon">✧</div><h3>Beleza</h3><p>Sobrancelhas, maquiagem e cuidados especiais para completar sua produção.</p></article>
    </div>
  </div>
</section>

<section id="experiencia" class="video-section">
  <?php $video = get_theme_mod('bella_video_url'); ?>
  <?php if ($video): ?>
    <video class="video-bg" autoplay muted loop playsinline preload="metadata">
      <source src="<?php echo esc_url($video); ?>" type="video/mp4">
    </video>
  <?php else: ?>
    <div class="video-bg" style="background:linear-gradient(135deg,#8f6c67,#d8a7a0);"></div>
  <?php endif; ?>
  <div class="video-overlay"></div>
  <div class="video-content container reveal">
    <div class="kicker">Uma experiência diferente</div>
    <h2>Entre, respire e aproveite seu momento.</h2>
    <p>Use esta área para mostrar vídeos curtos do salão, da equipe, dos detalhes e da experiência que espera por cada cliente.</p>
    <a class="btn btn-primary" href="<?php echo esc_url(bella_studio_whatsapp_url()); ?>" target="_blank" rel="noopener">Quero viver essa experiência</a>
  </div>
</section>

<section class="section">
  <div class="container about-grid">
    <div class="about-image reveal-left"><img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/placeholder.svg'); ?>" alt="Profissional do salão"></div>
    <div class="about-copy reveal-right">
      <div class="kicker">Mais que um salão</div>
      <h2>Um espaço para você se olhar e gostar ainda mais do que vê.</h2>
      <p>Conte aqui a história do salão, a filosofia de atendimento e o que torna a experiência única. O texto pode ser alterado posteriormente no editor do tema.</p>
      <div class="stats">
        <div class="stat"><strong>+10</strong><span>anos de experiência</span></div>
        <div class="stat"><strong>5k+</strong><span>clientes atendidas</span></div>
        <div class="stat"><strong>4.9★</strong><span>avaliação média</span></div>
      </div>
    </div>
  </div>
</section>

<section id="galeria" class="section">
  <div class="container">
    <div class="section-head center reveal"><div class="kicker">Galeria</div><h2>Inspire-se para seu próximo momento.</h2></div>
    <div class="gallery">
      <img class="tall reveal" src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/placeholder.svg'); ?>" alt="Resultado de beleza">
      <img class="reveal delay-1" src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/placeholder.svg'); ?>" alt="Detalhe do salão">
      <img class="reveal delay-2" src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/placeholder.svg'); ?>" alt="Beleza e estilo">
      <img class="reveal delay-1" src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/placeholder.svg'); ?>" alt="Ambiente">
      <img class="reveal delay-2" src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/placeholder.svg'); ?>" alt="Resultado">
    </div>
  </div>
</section>

<section id="depoimentos" class="section">
  <div class="container">
    <div class="section-head center reveal"><div class="kicker">Quem vive, recomenda</div><h2>O carinho de quem já passou por aqui.</h2></div>
    <div class="testimonials">
      <article class="quote reveal delay-1"><p>“Um atendimento maravilhoso e um resultado que superou minhas expectativas.”</p><small>— Mariana</small></article>
      <article class="quote reveal delay-2"><p>“O ambiente é lindo, acolhedor e a equipe cuida de cada detalhe.”</p><small>— Juliana</small></article>
      <article class="quote reveal delay-3"><p>“Virou meu lugar de autocuidado. Saio daqui me sentindo renovada.”</p><small>— Camila</small></article>
    </div>
  </div>
</section>

<section id="agendamento" class="section">
  <div class="container">
    <div class="cta reveal">
      <div><div class="kicker">Seu próximo momento começa aqui</div><h2>Pronta para reservar seu horário?</h2><p>Fale com nossa equipe pelo WhatsApp e encontre o melhor horário para você.</p></div>
      <a class="btn btn-primary" href="<?php echo esc_url(bella_studio_whatsapp_url()); ?>" target="_blank" rel="noopener">Agendar pelo WhatsApp</a>
    </div>
  </div>
</section>
</main>
<?php get_footer(); ?>
