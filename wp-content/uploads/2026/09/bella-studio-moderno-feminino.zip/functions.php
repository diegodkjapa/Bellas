<?php
if (!defined('ABSPATH')) exit;

function bella_studio_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo');
    add_theme_support('html5', array('search-form','comment-form','comment-list','gallery','caption','style','script'));
    register_nav_menus(array('primary' => __('Menu Principal', 'bella-studio')));
}
add_action('after_setup_theme', 'bella_studio_setup');

function bella_studio_assets() {
    wp_enqueue_style('bella-studio-style', get_stylesheet_uri(), array(), '1.0.0');
    wp_enqueue_script('bella-studio-js', get_template_directory_uri() . '/assets/js/main.js', array(), '1.0.0', true);
}
add_action('wp_enqueue_scripts', 'bella_studio_assets');

function bella_studio_customize_register($wp_customize) {
    $wp_customize->add_section('bella_hero', array(
        'title' => 'Bella Studio - Hero',
        'priority' => 30
    ));
    $wp_customize->add_setting('bella_whatsapp', array('default' => '5511999999999', 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('bella_whatsapp', array(
        'label' => 'WhatsApp (somente números)',
        'section' => 'bella_hero',
        'type' => 'text'
    ));
    $wp_customize->add_setting('bella_video_url', array('default' => '', 'sanitize_callback' => 'esc_url_raw'));
    $wp_customize->add_control(new WP_Customize_Media_Control($wp_customize, 'bella_video_url', array(
        'label' => 'Vídeo de fundo do ambiente',
        'section' => 'bella_hero',
        'mime_type' => 'video'
    )));
    $wp_customize->add_setting('bella_hero_image', array('default' => '', 'sanitize_callback' => 'absint'));
    $wp_customize->add_control(new WP_Customize_Media_Control($wp_customize, 'bella_hero_image', array(
        'label' => 'Imagem principal',
        'section' => 'bella_hero',
        'mime_type' => 'image'
    )));
}
add_action('customize_register', 'bella_studio_customize_register');

function bella_studio_whatsapp_url($message = 'Olá! Gostaria de agendar um horário no salão.') {
    $phone = get_theme_mod('bella_whatsapp', '5511999999999');
    return 'https://wa.me/' . preg_replace('/\D+/', '', $phone) . '?text=' . rawurlencode($message);
}
