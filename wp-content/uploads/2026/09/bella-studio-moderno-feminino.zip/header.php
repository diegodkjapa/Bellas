<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header class="site-header">
  <div class="container header-inner">
    <a class="logo" href="<?php echo esc_url(home_url('/')); ?>">Bella<span>Studio</span></a>
    <button class="menu-toggle" aria-label="Abrir menu" aria-expanded="false">☰</button>
    <nav class="menu" aria-label="Menu principal">
      <a href="#servicos">Serviços</a>
      <a href="#experiencia">Experiência</a>
      <a href="#galeria">Galeria</a>
      <a href="#depoimentos">Depoimentos</a>
      <a href="#agendamento">Agendamento</a>
    </nav>
  </div>
</header>
