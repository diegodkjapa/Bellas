<?php
add_action('admin_menu',function(){
add_menu_page('Smart Booking Manager','Agendamentos','manage_options','sbm-dashboard',function(){
echo '<div class="wrap"><h1>Smart Booking Manager</h1></div>';
});
add_submenu_page('sbm-dashboard','Profissionais','Profissionais','manage_options','sbm-professionals',function(){
echo '<div class="wrap"><h2>Profissionais</h2></div>';
});
add_submenu_page('sbm-dashboard','Serviços','Serviços','manage_options','sbm-services',function(){
echo '<div class="wrap"><h2>Serviços</h2></div>';
});
});
