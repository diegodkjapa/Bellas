<?php
add_action('admin_menu',function(){
add_submenu_page(
'sbm-dashboard',
'Calendário',
'Calendário',
'manage_options',
'sbm-calendar',
function(){
echo '<div class="wrap"><h1>Calendário de Agendamentos</h1></div>';
});
});
