<?php

add_action('admin_menu',function(){

add_submenu_page(
'sbm-dashboard',
'Clientes',
'Clientes',
'manage_options',
'sbm-clients',
function(){

echo '<div class="wrap">';
echo '<h1>Clientes</h1>';
echo '<p>Gerenciamento de clientes cadastrado.</p>';
echo '</div>';

});

});
