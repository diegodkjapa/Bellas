<?php

add_action('wp_dashboard_setup', function(){

wp_add_dashboard_widget(
'sbm_statistics',
'Smart Booking Manager',
function(){

$data = SBM_Reports::get_summary();

echo '<div>';
echo '<p>Agendamentos: '.$data['appointments'].'</p>';
echo '<p>Clientes: '.$data['clients'].'</p>';
echo '<p>Profissionais: '.$data['professionals'].'</p>';
echo '<p>Serviços: '.$data['services'].'</p>';
echo '</div>';

}
);

});
