<?php

add_action('admin_menu',function(){

add_submenu_page(
'sbm-dashboard',
'Configurações',
'Configurações',
'manage_options',
'sbm-settings',
function(){

$settings=SBM_Settings::get();

echo '<div class="wrap">';
echo '<h1>Smart Booking Manager</h1>';
echo '<h2>Personalização</h2>';
echo '<form method="post">';
echo '<p>Cor principal</p>';
echo '<input type="text" name="primary_color" value="'.$settings['primary_color'].'">';
echo '<p>Cor secundária</p>';
echo '<input type="text" name="secondary_color" value="'.$settings['secondary_color'].'">';
echo '<br><br><button class="button button-primary">Salvar</button>';
echo '</form>';
echo '</div>';

}
);

});
