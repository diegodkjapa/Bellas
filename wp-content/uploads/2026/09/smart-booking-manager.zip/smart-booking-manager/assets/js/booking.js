
console.log('Smart Booking Manager Frontend');
