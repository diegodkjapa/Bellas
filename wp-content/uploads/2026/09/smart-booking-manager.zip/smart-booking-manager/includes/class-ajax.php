<?php
class SBM_Ajax {

public static function get_slots(){

$date=sanitize_text_field($_POST['date'] ?? '');

$slots=[
'08:00',
'08:30',
'09:00',
'09:30',
'10:00'
];

wp_send_json_success([
'date'=>$date,
'slots'=>$slots
]);

}

}
