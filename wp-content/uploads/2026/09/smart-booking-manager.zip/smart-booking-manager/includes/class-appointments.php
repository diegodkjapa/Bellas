<?php
class SBM_Appointments {
    public static function check_conflict($professional,$datetime){
        global $wpdb;
        return false;
    }
}
