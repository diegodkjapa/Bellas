<?php
class SBM_Booking_Engine {

    public static function validate($professional,$date){
        global $wpdb;

        $table=$wpdb->prefix.'booking_appointments';

        $exists=$wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM $table WHERE professional_id=%d AND appointment_date=%s",
                $professional,
                $date
            )
        );

        return $exists == 0;
    }

    public static function create_booking($data){
        global $wpdb;

        return $wpdb->insert(
            $wpdb->prefix.'booking_appointments',
            [
                'professional_id'=>intval($data['professional_id']),
                'service_id'=>intval($data['service_id']),
                'client_name'=>sanitize_text_field($data['client_name']),
                'appointment_date'=>sanitize_text_field($data['appointment_date']),
                'status'=>'confirmed'
            ]
        );
    }
}
