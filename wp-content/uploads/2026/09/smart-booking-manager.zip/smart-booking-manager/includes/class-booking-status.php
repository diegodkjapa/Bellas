<?php
class SBM_Booking_Status {

public static function get_statuses(){

return [
'pending'=>'Aguardando',
'confirmed'=>'Confirmado',
'completed'=>'Concluído',
'cancelled'=>'Cancelado'
];

}

}
