<?php
class SBM_Calendar {
    public static function get_available_slots($date,$professional){
        return [];
    }

    public static function views(){
        return [
            'day',
            'week',
            'month'
        ];
    }

}
