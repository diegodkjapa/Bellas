<?php
class SBM_Client_Manager {

public static function create($data){
    global $wpdb;

    $wpdb->insert(
        $wpdb->prefix.'booking_clients',
        [
            'name'=>sanitize_text_field($data['name']),
            'email'=>sanitize_email($data['email']),
            'phone'=>sanitize_text_field($data['phone'])
        ]
    );

    return $wpdb->insert_id;
}

}
