<?php
class SBM_Database {
public static function create_tables(){
global $wpdb;
require_once ABSPATH.'wp-admin/includes/upgrade.php';
$c=$wpdb->get_charset_collate();

$sql=[
"CREATE TABLE {$wpdb->prefix}booking_professionals (
id bigint AUTO_INCREMENT PRIMARY KEY,
name varchar(255),
email varchar(255),
phone varchar(50),
status varchar(20)
)$c;",
"CREATE TABLE {$wpdb->prefix}booking_services (
id bigint AUTO_INCREMENT PRIMARY KEY,
name varchar(255),
description text,
duration int,
price decimal(10,2),
status varchar(20)
)$c;"
];

foreach($sql as $q) dbDelta($q);
}
}
