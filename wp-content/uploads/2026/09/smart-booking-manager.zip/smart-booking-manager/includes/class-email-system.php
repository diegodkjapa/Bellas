<?php
class SBM_Email_System {

public static function booking_created($email,$name){

wp_mail(
$email,
'Agendamento confirmado',
'Olá '.$name.', seu agendamento foi confirmado.'
);

}

}
