<?php
class SBM_Frontend_Booking {

public static function render(){

ob_start();

include SBM_PATH.'templates/frontend-booking.php';

return ob_get_clean();

}

}
