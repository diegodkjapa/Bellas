<?php
class SBM_Notifications {

public static function send_new_booking($email,$name){
    wp_mail(
        $email,
        'Novo agendamento',
        'Olá '.$name.', seu agendamento foi registrado.'
    );
}

}
