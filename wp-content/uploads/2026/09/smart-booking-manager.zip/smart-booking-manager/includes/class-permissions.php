<?php
class SBM_Permissions {

public static function can_manage(){
    return current_user_can('manage_options') ||
           current_user_can('sbm_manager');
}

public static function can_view_schedule(){
    return current_user_can('sbm_professional') ||
           self::can_manage();
}

}
