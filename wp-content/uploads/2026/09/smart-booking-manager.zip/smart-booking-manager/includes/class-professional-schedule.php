<?php
class SBM_Professional_Schedule {

public static function default_schedule(){

return [
'monday'=>[
'start'=>'08:00',
'end'=>'18:00',
'break_start'=>'12:00',
'break_end'=>'13:00'
],
'tuesday'=>[
'start'=>'08:00',
'end'=>'18:00'
],
'wednesday'=>[
'start'=>'08:00',
'end'=>'18:00'
],
'thursday'=>[
'start'=>'08:00',
'end'=>'18:00'
],
'friday'=>[
'start'=>'08:00',
'end'=>'18:00'
]
];

}

}
