<?php
class SBM_Reports {

public static function get_summary(){
    global $wpdb;

    return [
        'appointments'=>0,
        'clients'=>0,
        'professionals'=>0,
        'services'=>0
    ];
}

}
