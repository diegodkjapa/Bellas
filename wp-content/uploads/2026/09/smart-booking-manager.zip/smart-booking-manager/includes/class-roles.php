<?php
class SBM_Roles{
public static function create_roles(){
add_role('sbm_manager','Gerente',['read'=>true]);
add_role('sbm_professional','Profissional',['read'=>true]);
}
}
