<?php
class SBM_Settings {

public static function install(){
    if(get_option('sbm_settings') === false){
        add_option('sbm_settings',[
            'primary_color'=>'#222222',
            'secondary_color'=>'#c9a227',
            'calendar_style'=>'clean'
        ]);
    }
}

public static function get(){
    return get_option('sbm_settings',[]);
}

}
