<?php
class SBM_Shortcodes {

public static function register(){
    add_shortcode('booking_calendar',[self::class,'calendar']);
}

public static function calendar(){
    ob_start();
    include SBM_PATH.'templates/booking-calendar.php';
    return ob_get_clean();
}

}
