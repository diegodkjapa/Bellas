<?php
class SBM_User_Dashboard {

public static function get_menu(){
    if(current_user_can('sbm_professional')){
        return ['Minha Agenda','Meus Clientes'];
    }

    return ['Agenda','Profissionais','Serviços','Clientes'];
}

}
