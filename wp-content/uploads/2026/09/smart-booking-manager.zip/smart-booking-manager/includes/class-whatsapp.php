<?php
class SBM_Whatsapp {

public static function generate_link($phone,$message){

return 'https://wa.me/'.preg_replace('/[^0-9]/','',$phone).'?text='.urlencode($message);

}

}
