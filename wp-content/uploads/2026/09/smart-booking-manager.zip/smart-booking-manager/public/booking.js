jQuery(function($){

console.log('Booking engine loaded');

});