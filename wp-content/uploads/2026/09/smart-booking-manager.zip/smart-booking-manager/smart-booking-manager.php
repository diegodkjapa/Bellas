<?php
/*
Plugin Name: Smart Booking Manager
Description: Sistema profissional de agendamento WordPress.
Version: 1.1.0
*/
if(!defined('ABSPATH')) exit;

define('SBM_PATH', plugin_dir_path(__FILE__));


foreach([
'includes/class-database.php',
'includes/class-roles.php',
'includes/class-calendar.php',
'includes/class-professional',
'includes/class-professionals.php'
'includes/class-appointments.php',
'includes/class-services.php',
'admin/calendar-page.php',
'admin/admin-menu.php',
'includes/class-shortcodes.php',
'includes/class-booking-engine.php',
'admin/settings-page.php',
'includes/class-settings.php',
'includes/class-notifications.php',
'includes/class-professional-schedule.php',
'includes/class-ajax.php',
'admin/clients-page.php',
'includes/class-client-manager.php',
// 'includes/class-calendar.php',
// 'includes/class-booking-engine.php',
'includes/class-user-dashboard.php',
'includes/class-permissions.php',
// 'includes/class-user-dashboard.php',
'includes/class-reports.php',
'admin/dashboard-widgets.php',
'includes/class-email-system.php',
'includes/class-booking-status.php',
'includes/class-frontend-booking.php',
'includes/class-whatsapp.php'

] as $file){
    require_once SBM_PATH.$file;
}

register_activation_hook(__FILE__, function(){
    SBM_Database::create_tables();
    SBM_Roles::create_roles();
});

add_action('init', function(){
    SBM_Shortcodes::register();
});

register_activation_hook(__FILE__, function(){
    SBM_Settings::install();
});

add_action('wp_ajax_sbm_get_slots',[SBM_Ajax::class,'get_slots']);

add_action('wp_ajax_nopriv_sbm_get_slots',[SBM_Ajax::class,'get_slots']);

add_shortcode('booking_calendar',[SBM_Frontend_Booking::class,'render']);