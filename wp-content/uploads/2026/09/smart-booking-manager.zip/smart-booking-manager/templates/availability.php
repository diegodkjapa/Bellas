<div class="sbm-availability">
<h3>Horários disponíveis</h3>
<div class="slots"></div>
</div>
