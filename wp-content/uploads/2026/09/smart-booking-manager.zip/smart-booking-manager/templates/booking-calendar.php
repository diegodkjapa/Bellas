<div class="sbm-booking-box">
<h2>Agendamento</h2>

<div class="sbm-step">
<label>Escolha o serviço</label>
<select>
<option>Selecione</option>
</select>
</div>

<div class="sbm-step">
<label>Escolha o profissional</label>
<select>
<option>Selecione</option>
</select>
</div>

<div class="sbm-step">
<label>Data</label>
<input type="date">
</div>

<button>Continuar</button>

</div>
