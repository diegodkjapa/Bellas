<div class="sbm-confirmation">
<h3>Agendamento realizado</h3>
</div>
