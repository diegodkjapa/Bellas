<div class="sbm-calendar">
Calendário de agendamentos
</div>