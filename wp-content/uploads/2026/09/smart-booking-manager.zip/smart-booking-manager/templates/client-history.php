<div class="sbm-client-history">
<h3>Histórico de agendamentos</h3>
</div>
