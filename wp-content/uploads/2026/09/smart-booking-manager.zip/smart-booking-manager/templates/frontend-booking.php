<div class="sbm-public-booking">

<h2>Agendamento Online</h2>

<div class="step">
<select>
<option>Escolha o serviço</option>
</select>
</div>

<div class="step">
<select>
<option>Escolha o profissional</option>
</select>
</div>

<div class="step">
<input type="date">
</div>

<div class="step">
<button>Confirmar agendamento</button>
</div>

</div>
