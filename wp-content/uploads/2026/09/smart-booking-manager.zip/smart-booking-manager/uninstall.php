<?php
// Limpeza futura ao remover plugin.
